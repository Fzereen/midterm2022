-----------------------------------------------------------------
Midterm
-----------------------------------------------------------------

git clone https://github.com/PeopleNTech2/midterm-coding-exam.git

-----------------------------------------------------------------

***for the first push:

you need to create your own new repo on github

git remote show origin

git remote rm origin

git remote add origin (your own github url)

git init

git add .

git commit -m "name of the topic"

git push -u origin master

-----------------------------------------------------------------

*** next pushes:

git add .

git commit -m "name of the topic"

git push -u origin master

-----------------------------------------------------------------

6 pushes required

every time you finish a topic, you need to push your work

-----------------------------------------------------------------

submit your midterm github url to the link below:

https://forms.gle/KYfHSc5iNW6PenGc8